---
name: fresh-angles
description: "Finds angles for a post, an ad, a campaign or a hook that are not the obvious ones. Use for give me angles on X, brainstorm X, ideas for X, make this less generic."
---

# fresh-angles: ideas that are not the first ten

The first ideas anyone has are the ones everyone has. This skill throws those away and looks further.

## Steps
1. Ask two questions if you do not know the answers: who is this for, and what should they do or feel after it?
2. Write the 8 most obvious angles for the topic. Do not show them yet.
3. Now look somewhere else. Write new angles from each of these four places:
   - **The bad day:** the worst moment the reader has with this problem. Be specific about where they are and what just went wrong.
   - **The opposite:** take the claim everyone makes about this topic and argue the reverse, where the reverse is honestly true.
   - **The detail:** one small, concrete thing only an insider would notice.
   - **The cost of doing nothing:** what happens in a year if the reader changes nothing.
4. Cut every new angle that is close to one of the 8 obvious ones.
5. Show the 5 best that are left. For each one give: a working headline, one line on why it is not obvious, and its weakest point.
6. Then show the 8 obvious ones in a short list called "What I threw away", so the user can see the difference.

## Rules
- Use only facts the user gave you. Never invent a number, a customer or a result to make an angle stronger.
- An angle is a point of view, not a format. "A carousel" is not an angle.
- If fewer than 5 angles survive, show fewer. Do not pad the list.
- Never use em dashes.
