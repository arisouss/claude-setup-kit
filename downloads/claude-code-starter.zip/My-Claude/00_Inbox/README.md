Drop new files here for Claude to look at.
