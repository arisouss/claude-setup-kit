Your logo, colors, fonts and brand guide, if you have them.
