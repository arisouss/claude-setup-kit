Reference documents about your customers, products and market. Claude opens these only when a task needs them.
