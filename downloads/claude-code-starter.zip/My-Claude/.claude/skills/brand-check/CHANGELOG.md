# Patch notes

## Version 2.0
- Checks the look, the words and AI-sounding copy against your own brand guide.
- Lists every claim that needs a source.
- Stops after the report and asks before it makes an on-brand version, so it does not use your limit without your OK.
- An on-brand version is always saved as a new file. The original is never changed.

## Version 1.0
- First version. Checked logo, colors and fonts.
