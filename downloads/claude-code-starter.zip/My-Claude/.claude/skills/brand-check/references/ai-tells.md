# AI tells: patterns that make copy sound machine-written

Flag each one you find. Quote the sentence.

- Em dashes, or many dashes used as pauses.
- "Not just X, but Y" and "It is not about X. It is about Y."
- Lists of three by habit ("fast, reliable and scalable").
- Openers such as "In today's fast-paced world", "In the ever-evolving landscape", "Let's dive in".
- Empty enthusiasm: "excited to announce", "thrilled", "game-changing".
- Sentences that restate the one before in other words.
- A closing line that sums up what was just said ("In short", "Ultimately").
- Questions used as hooks ("Ever wondered why...?").
- Vague claims with no number ("significantly faster", "dramatically reduces").
- Emoji in business copy.
- Every paragraph the same length and rhythm.
