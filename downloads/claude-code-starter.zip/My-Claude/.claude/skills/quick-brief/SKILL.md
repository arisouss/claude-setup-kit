---
name: quick-brief
description: "Turns a long document, transcript or messy notes into a two sentence summary, 5 key points and a list of actions. Use for quick brief, summarize this, break this down."
---

# quick-brief: the bottom line of a long document

## Steps
1. Read the whole document. If it is not attached or you cannot open it, ask for it.
2. Write, in this order:
   - **Bottom line:** two sentences. What it is and why it matters to the reader.
   - **5 key points:** one line each.
   - **Actions:** what must be done, who it is for, and the date if one is given.
   - **Not clear:** anything the document leaves open or contradicts.

## Rules
- Use only what is in the document. Do not add facts, numbers or names.
- Keep every number exactly as written.
- Plain words, short sentences. Never use em dashes.
- If the document is longer than you could read in full, say which part you did not read.
