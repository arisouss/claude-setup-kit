---
name: plain-rewrite
description: "Rewrites a draft so it reads like a person wrote it: plain, short and factual, with every fact kept. Use for make this plain, make this sound human, tighten this, remove the fluff."
---

# plain-rewrite: same facts, plain words

## Steps
1. Read the draft. List every fact in it for yourself: numbers, names, dates, claims.
2. Rewrite it:
   - Short sentences. One idea each.
   - Start with the reader's problem or the bottom line.
   - Say the number, or say nothing. Cut "significant", "dramatic", "substantial".
   - Cut hype words: revolutionary, game-changing, cutting-edge, seamless, robust, leverage, unlock, empower, world-class, innovative.
   - Cut filler: very, really, truly, simply, just, basically.
   - No em dashes. No exclamation marks. No question as an opening line.
3. Check your rewrite against your fact list. Every fact must still be there, unchanged.
4. Show the rewrite first. Then show 3 lines on what you changed.

## Rules
- Never add a fact, a number or a claim that was not in the draft.
- If a sentence has no fact and no purpose, cut it and say so.
- Keep the user's meaning. If something is unclear, ask before you guess.
