One or two pieces of your best work, as examples of what good looks like.
