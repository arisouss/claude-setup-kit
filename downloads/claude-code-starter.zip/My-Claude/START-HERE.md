# First run: set this folder up

Claude: follow these steps in order. The person is not technical.

## How to talk
- Ask ONE question per message, then wait.
- Plain words. Number the choices so the person can answer with a number.
- If they say "skip" or "I don't know", pick the simplest option and carry on.

## Step 1. Interview (one question per message)
1. What is your first name, and what do you do?
2. What kind of work is it? 1 Marketing, 2 Sales, 3 I run my own business, 4 Creator or freelancer, 5 Other.
3. What are the 3 main things you work on right now? Ask for a short name for each.
4. What do you make most often? 1 Emails, 2 Social posts, 3 Decks, 4 Briefs and plans, 5 Reports and spreadsheets, 6 Web pages, 7 Something else. Several are fine.
5. Who is your work for? For example: clients, customers, followers, a boss.
6. How do you like answers? 1 Short bullets or 2 full drafts. And 1 formal or 2 casual.
7. Is there anything I must never do for you?

## Step 2. What their other AI tool knows (optional)
Say: "Do you already use ChatGPT, Gemini or another AI tool? If yes, I will give you a short prompt to paste there, so I can learn what it already knows about you. Answer yes or skip."

If yes, show this prompt in a code block and ask them to paste the answer back:

    Write down everything you have remembered about me from our past chats, so I can give it to a new assistant. Only what you actually remember, no guessing. Short bullets under these headings: Who I am; My work; My projects; Tools I use; How I like answers; Things I do not like. Leave out health, money, family, passwords and home address.

From what they paste, keep only what helps with their work.

## Step 3. Write it down
- Replace everything in about-me.md with what you learned: who they are, their 3 main things, what they make, who it is for, how they like answers, what you must never do, and the useful facts from Step 2. Keep it under 60 lines.
- Create one subfolder in 01_Projects for each of their 3 main things.
- Do not change CLAUDE.md, except to add a rule they asked for in question 7.

## Step 4. Show and check
Tell them in 5 short bullets what you now know about them. Ask them to correct anything that is wrong, and fix about-me.md.

## Step 5. First real task
Ask for one small real task from their week, something they already know how to do well, and do it with them.
