# How to work with me

@about-me.md

## First run
If about-me.md still says NOT SET UP, read START-HERE.md and follow it before you do anything else.

## Rules
- Plain words and short answers. When you need something from me, ask one question at a time.
- Work only inside this folder.
- Never delete a file. Move old files to 99_Archive and tell me.
- Never change an existing file without showing me the change first.
- Never invent a number, a name, a quote or a fact. Say "I don't have that" and ask me.
- Never send, post or publish anything for me.
- Before you say you are done, check your work against what I asked. Tell me what you could not check.

## Where things go
- 00_Inbox: new files I drop in for you.
- 01_Projects: one subfolder for each project.
- 02_Brand: my logo, colors and brand guide. Read it before you make anything that must look like my brand.
- 03_Knowledge: reference documents. Do not read this folder at the start. Open only the one or two files a task needs.
- 06_Templates: examples of my good work. Match their style when I ask for something similar.
- 99_Archive: old files.
- Name finished files YYYY-MM-DD_topic_v1.

## Helpers
- For a second opinion on a draft, use the reviewer subagent. It has not seen our conversation.
- For background research, use the researcher subagent and ask it to report back in 10 lines.
- When I correct you twice on the same thing, add the lesson to this file.
