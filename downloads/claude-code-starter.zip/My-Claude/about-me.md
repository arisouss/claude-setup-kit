NOT SET UP

Claude fills this file in during the first run. After that you can open it and change anything.
